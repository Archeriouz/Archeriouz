#!/bin/bash

clear

while [ 0 ]
do
echo ""
echo -n -e "\e[91mGithack\e[0m \e[91m>>\e[0m \e[92m"; read Command
echo ""

if [ "${Command}" == "Passtack" ] || [ "${Command}" == "passtack" ]
then
clear
echo -n -e "\e[91mPassword Lenght\e[0m \e[91m>>\e[0m \e[92m"; read Passght
echo ""
echo -n -e "\e[91mPassword Number\e[0m \e[91m>>\e[0m \e[92m"; read Passnum

for i in $(seq 1 $Passnum)
do
	openssl rand -base64 48 | cut -c1-$Passght >> Save.txt
cat Save.txt
done
hashcat index.txt Save.txt
echo ""
echo -e "Passwords Saved to Save.txt"
echo ""
else
echo -e "Command Not Found."
fi 

done

exit 0
