#!/bin/bash

clear

sleep 1

echo -e "\e[91mImport\e[0m \e[91m:\e[95m This Will Remove Source Data Files of \e[92mGithack. \e[91mRemove\e[0m \e[95manyway? [N/y]\e[0m"

read Choice

if [ "${Choice}" == "N" ] || [ "${Choice}" == "n" ] || [ "${Choice}" == "No" ] || [ "${Choice}" == "no" ]
then
sleep 0.5
clear
echo -e "\e[92mGood Choice!, \e[93mEnjoy.\e[0m"
exit
fi

clear

echo -e "\e[91mGood Bye.\e[0m"

rm -rf ../Githack
